﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HealthInsApiApp.Data
{
    //in this class we get data and it implements IMemberClaimsRepository. if we use database then we use DataContext object and retrueve with it
    public class MemberClaimRepository : IMemberClaimRepository
    {
        private readonly MemberClaimContext _context;
        //  private readonly ILogger<MemberClaimRepository> _logger;

        //public MemberClaimRepository(MemberClaimContext context, ILogger<MemberClaimRepository> logger)
        //{
        //    _context = context;
        //    _logger = logger;
        //}

        public MemberClaimRepository(MemberClaimContext context)
        {
            _context = context;
            //   _logger = logger;
        }


        public async Task<IEnumerable<Member>> GetAllMembers(bool includeClaims = false)
        {
            //  _logger.LogInformation($"Getting all Members");

            var resultTask = await _context.ReadMemberData();

            IEnumerable<Member> members = resultTask.ToList();

            if (includeClaims)
            {
                // _logger.LogInformation($"Getting claims and assigning");

                var resultclaimTask = await _context.ReadClaimData();
                IEnumerable<Claim> claims = resultclaimTask.ToList();

                foreach (Member m in members)
                {
                    m.Claims = claims.Where(claim => claim.MemberID == m.MemberID).ToList();

                }

            }

            return members;
        }

        public async Task<IEnumerable<Member>> GetAllMembersByClaimDate(DateTime claimDate)
        {
            //  _logger.LogInformation($"Getting all Members");

            var resultTask = await GetAllMembers(true);

            IEnumerable<Member> members = resultTask.ToList();

            List<Member> membersbyDate = new List<Member>();
            foreach (Member m in members)
            {

                var result = m.Claims.Where(cl => cl.ClaimDate == claimDate).Any();
                if (result)
                    membersbyDate.Add(m);
            }

            return membersbyDate;
        }

      
        public async Task<Member> GetMember(int MemberId, bool includeClaims = false)
        {
            // _logger.LogInformation($"Getting all Members");

            var resultTask = await GetAllMembers(includeClaims);

            IEnumerable<Member> members = resultTask.ToList();

            Member member = members.Where(m => m.MemberID == MemberId).FirstOrDefault();

            if (includeClaims)
            {
                //  _logger.LogInformation($"Getting claims and assigning");

                var resultclaimTask = await _context.ReadClaimData();
                IEnumerable<Claim> claims = resultclaimTask.ToList();

                member.Claims = claims.Where(claim => claim.MemberID == member.MemberID).ToList();



            }
            return member;
        }

        //public async Task<Member> GetMemberByClaimDate(int MemberId, DateTime claimDate)
        //{
        //    //  _logger.LogInformation($"Getting all Members");

        //    var resultTask = await GetAllMembersByClaimDate(claimDate);

        //    IEnumerable<Member> members = resultTask.ToList();

        //    Member member = members.Where(m => m.MemberID == MemberId).FirstOrDefault();


        //    return member;
        //}
}
}
