﻿using CsvHelper;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;

namespace HealthInsApiApp.Data
{
    public class MemberClaimContext   // mostly inherits from DbContext
    {
        string CurrApplicationDataFolder = System.IO.Directory.GetCurrentDirectory() + "\\Data";

        public MemberClaimContext() 
        {
            //// LoadData();
            //members = ReadMemberData();
            //claims = ReadClaimData();
        }

        // commented out blow methods which used to see if we are able to get data
        //protected IEnumerable<Member> ReadMemberData()
        //{
        //    // List<Member> members = new List<Member>();
        //    using (var reader = new System.IO.StreamReader("C:\\Users\\SoumyaGT\\source\\repos\\ConsoleApp1\\Data\\Member.csv"))
        //    using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
        //    {
        //        var records = new List<Member>();
        //        csv.Read();
        //        csv.ReadHeader();
        //        while (csv.Read())
        //        {
        //            var record = new Member()
        //            {
        //                MemberID = csv.GetField<int>("MemberID"),
        //                FirstName = csv.GetField("FirstName"),
        //                LastName = csv.GetField("LastName"),
        //                EnrollmentDate = csv.GetField<DateTime>("EnrollmentDate")
        //            };
        //            records.Add(record);
        //        }
        //        return records;
        //    }

        //}

        //protected IEnumerable<Claim> ReadClaimData()
        //{
        //    // List<Claim> claims = new List<Claim>();
        //    using (var reader = new System.IO.StreamReader("C:\\Users\\SoumyaGT\\source\\repos\\ConsoleApp1\\Data\\Claim.csv"))
        //    using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
        //    {

        //        var records = new List<Claim>();
        //        csv.Read();
        //        csv.ReadHeader();
        //        while (csv.Read())
        //        {
        //            var record = new Claim()
        //            {
        //                MemberID = csv.GetField<int>("MemberID"),
        //                ClaimDate = csv.GetField<DateTime>("ClaimDate"),
        //                ClaimAmount = csv.GetField<decimal>("ClaimAmount")

        //            };
        //            records.Add(record);
        //        }
        //        return records;


        //    }
        //    //  return claims;
        //}

        public async Task<IEnumerable<Member>> ReadMemberData()
        {
            //CurrApplicationDataFolder
            // List<Member> members = new List<Member>();
            //using (var reader = new System.IO.StreamReader("C:\\Users\\SoumyaGT\\source\\repos\\ConsoleApp1\\Data\\Member.csv"))
            using (var reader = new System.IO.StreamReader(CurrApplicationDataFolder + "\\Member.csv"))
            using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
            {
                var records = new List<Member>();
                await csv.ReadAsync();
                csv.ReadHeader();
                while (await csv.ReadAsync())
                {
                    var record = new Member()
                    {
                        MemberID = csv.GetField<int>("MemberID"),
                        FirstName = csv.GetField("FirstName"),
                        LastName = csv.GetField("LastName"),
                        EnrollmentDate = csv.GetField<DateTime>("EnrollmentDate")
                    };
                    records.Add(record);
                }
                return records;
            }

        }

        public async Task<IEnumerable<Claim>> ReadClaimData()
        {
            // List<Claim> claims = new List<Claim>();
            //using (var reader = new System.IO.StreamReader("C:\\Users\\SoumyaGT\\source\\repos\\ConsoleApp1\\Data\\Claim.csv"))
            using (var reader = new System.IO.StreamReader(CurrApplicationDataFolder + "\\Claim.csv"))
            using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
            {

                var records = new List<Claim>();
                await csv.ReadAsync();
                csv.ReadHeader();
                while (await csv.ReadAsync())
                {
                    var record = new Claim()
                    {
                        MemberID = csv.GetField<int>("MemberID"),
                        ClaimDate = csv.GetField<DateTime>("ClaimDate"),
                        ClaimAmount = csv.GetField<decimal>("ClaimAmount")

                    };
                    records.Add(record);
                }
                return records;


            }
            //  return claims;
        }


    }
}
