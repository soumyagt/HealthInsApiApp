﻿using AutoMapper;
using HealthInsApiApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HealthInsApiApp.Data
{
    public class MemberProfile: Profile
    {
        //Didn't use but we usually will have Models that get populated with  database Entity classes. and will be used on api controllers.
        public MemberProfile()
        {
            this.CreateMap<Member, MemberModel>();
        }
    }
}
