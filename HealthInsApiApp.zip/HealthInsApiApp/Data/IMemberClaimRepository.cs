﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HealthInsApiApp.Data
{
    public interface IMemberClaimRepository
    {
        Task<IEnumerable<Member>> GetAllMembers(bool includeClaims = false);
        Task<Member> GetMember(int MemberId, bool includeClaims = false);
        Task<IEnumerable<Member>> GetAllMembersByClaimDate(DateTime claimDate);
       // Task<Member> GetMemberByClaimDate(int MemberId, DateTime claimDate); not needed we are getting claims for given date in above method
    }
}
