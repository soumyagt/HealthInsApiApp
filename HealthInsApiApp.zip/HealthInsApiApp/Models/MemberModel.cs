﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HealthInsApiApp.Models
{
    //not used
    public class MemberModel
    {
        // This class is what we return in controller
        public int MemberID { get; set; }
        public DateTime EnrollmentDate { get; set; } = DateTime.MinValue;

        public string FirstName { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;
        public ICollection<ClaimModel> Claims { get; set; } 

    }
}
