﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using HealthInsApiApp.Data;
using HealthInsApiApp.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
//using Newtonsoft.Json;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace HealthInsApiApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MembersController : ControllerBase
    {
        private readonly IMemberClaimRepository _repository;
        //  private readonly IMapper _mapper ;
        //public MembersController(IMemberClaimRepository  repository)
        //{
        //    _repository = repository;
        //}
        public MembersController()
        {
            // we usually inject DBContext (EF ) object at start up but here we are creating instance in COntroller itself.
            MemberClaimContext context = new MemberClaimContext();

            _repository = new MemberClaimRepository(context);

        }

        [HttpGet]
        //   public async Task<IActionResult> Get()
        public async Task<string> Get(bool includeClaims = false)
        {
            try
            {
                var results = await _repository.GetAllMembers(includeClaims);

                // return Ok(results);
                return JsonConvert.SerializeObject(results);
            }
            catch (Exception)
            {

                // return this.StatusCode(StatusCodes.Status500InternalServerError, "Internal Error");
                return JsonConvert.SerializeObject("Internal Error");
            }

        }


        [HttpGet("{id}")]
        //public async Task<IActionResult> Get(int id)
        public async Task<string> Get(int id, bool includeClaims = false)
        {
            var result = await _repository.GetMember(id, includeClaims);
            // return Ok(result);
            return JsonConvert.SerializeObject(result);

        }
        //  Task<IEnumerable<Member>> GetAllMembersByClaimDate(DateTime claimDate);
        //Task<Member> GetMemberByClaimDate(int MemberId, DateTime claimDate);


        [HttpGet("search")]
        // public async Task<IActionResult> SearchByClaimDate(string theDate)
        public async Task<string> SearchByClaimDate(string theDate)
        {
            try
            {
                DateTime claimdateDT = Convert.ToDateTime(theDate);
                var results = await _repository.GetAllMembersByClaimDate(claimdateDT);

                if (!results.Any())
                    return JsonConvert.SerializeObject(NotFound());

               // return Ok(results);
                    return JsonConvert.SerializeObject(results);
            }
            catch (Exception)
            {

               // return this.StatusCode(StatusCodes.Status500InternalServerError, "Internal Error");
                 return  JsonConvert.SerializeObject("Internal Error");
            }


        }


        // not needed
        //[HttpGet("{memberId}/{theDate}")]
        //public async Task<IActionResult> SearchMemberClaimDate(int memberId, string theDate)
        //{
        //    try
        //    {
        //        DateTime claimdateDT = Convert.ToDateTime(theDate);
        //        var results = await _repository.GetMemberByClaimDate(memberId, claimdateDT);

        //        if (results==null)
        //            return NotFound();

        //        return Ok(results);
        //        //    return JsonConvert.SerializeObject(results);
        //    }
        //    catch (Exception)
        //    {

        //        return this.StatusCode(StatusCodes.Status500InternalServerError, "Internal Error");
        //        // return  JsonConvert.SerializeObject("Internal Error");
        //    }


        //}

    }
}
